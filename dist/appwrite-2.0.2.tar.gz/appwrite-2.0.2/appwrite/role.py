class Role:
    @staticmethod
    def any():
        return 'any'

    @staticmethod
    def user(id, status = ""):
        if status:
            return f'user:{id}/{status}'
        return f'user:{id}'

    @staticmethod
    def users(status = ""):
        if status:
            return f'users/{status}'
        return 'users'
    
    @staticmethod
    def guests():
        return 'guests'

    @staticmethod
    def team(id, role = ""):
        if role:
            return f'team:{id}/{role}'
        return f'team:{id}'

    @staticmethod
    def member(id):
        return f'member:{id}'