class Permission:

    @staticmethod
    def read(role):
        return f'read("{role}")'

    @staticmethod
    def write(role):
        return f'write("{role}")'

    @staticmethod
    def create(role):
        return f'create("{role}")'

    @staticmethod
    def update(role):
        return f'update("{role}")'

    @staticmethod
    def delete(role):
        return f'delete("{role}")'
