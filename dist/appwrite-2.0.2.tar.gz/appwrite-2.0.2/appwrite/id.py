class ID:
    @staticmethod
    def custom(id):
        return id

    @staticmethod
    def unique():
        return 'unique()'